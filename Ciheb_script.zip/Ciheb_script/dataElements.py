import requests as rq
import pandas as pd
import xlsxwriter
import xlwings as xw
# Set the DHIS2 instance URL and API endpoint
dhis2_url = "https://crims.mgickenya.org"
api_endpoint = "/api/dataElements"

# Set your authentication credentials
username = "WImamai"
password = "Researcher@7"

# Set the parameters for your data value request
data_set_id = "Rjv7sNr9hEb"
period = "202307"
# List of organization unit IDs (facilities)
org_unit_ids = ["h8pJQvffN71","zTjUwJx8Mw0","cqUcX50S0g3","Y15A5d1De5q","EVGtiyRCiFL","xyaGAI5y5BB","bgPs2UcHIcc","tAKPrTA5jzk","WwYfrsmafhY","dwsqnJOgFCH"]

# Initialize a list to store data values
all_data_Elements = []
# Loop through each organization uni

for org_unit_id in org_unit_ids:
    # Construct the full API URL
    full_url = f"{dhis2_url}{api_endpoint}?dataElement={data_set_id}&period={period}&orgUnit={org_unit_id}"
    
    # Set up the authentication header
    auth = (username, password)
    
    # Make the GET request
    response = rq.get(full_url, auth=auth)
    
    # Check if the request was successful (HTTP status code 200)
    if response.status_code == 200:
        data_values = response.json().get("dataElements", [])
        all_data_Elements.extend(data_values)
    else:
        print(f"Failed to retrieve data values for facility {org_unit_id}. Status code:", response.status_code)
# Process the combined data values
for data_element in all_data_Elements:
    name = data_element.get("name")
    data_set = data_element.get("dataSet")
    org_unit = data_element.get("orgUnit")
    print(f"Facility: {org_unit}, Data Element: {data_element}, Name: {name}")

# Excel output of UIds popilation Dataset

all_data_Elements =pd.DataFrame(all_data_Elements)
workbook = xlsxwriter.Workbook('C:/Users/WImamai/OneDrive - Center For International Health, Education and Biosecurity - Kenya/Desktop/Ciheb/UIDS_Python.xlsx')
wb = xw.Book('UIDS_Python.xlsx')

wks = xw.sheets('dataElements')
#wks.range('A2:I9041').clear_contents()
wks.range('A1').value = all_data_Elements 
print(all_data_Elements)