import openpyxl

workbook = openpyxl.load_workbook('C:/Users/WImamai/OneDrive - Center For International Health, Education and Biosecurity - Kenya/Desktop/Ciheb/UIDS_Python.xlsx')
sheet = workbook['UIDS_dataValues']
# Access cell values
cell_value = sheet['A1']

# Define the range of cells to combine
start_row = 2
end_row = 5
column_letter = 'B'
column_letter = 'E'
 #Initialize an empty list to store the cell values
cell_values = []
print(cell_values)

# Iterate through the specified range of cells and store their values
for row in range(start_row, end_row + 1):
    cell = sheet[column_letter + str(row)]
    cell_values.append(cell.value)

# Combine cell values into a single string
combined_text = " ".join(map(str, cell_values))

# Place the combined text in a target cell
target_cell = sheet['D1']
target_cell.value = combined_text

# Save changes to the workbook
workbook.save('modified_example.xlsx')

# Close the workbook when done
workbook.close()



